const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { recoverPersonalSignature } = require('@metamask/eth-sig-util');
const { bufferToHex } = require('ethereumjs-util');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

// Generate or find user by wallet address
exports.getNonce = async (req, res, next) => {
  try {
    const { walletAddress } = req.params;
    
    if (!walletAddress || !walletAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      return res.status(400).json({ error: 'Invalid wallet address' });
    }
    
    let user = await User.findOne({ walletAddress: walletAddress.toLowerCase() });
    
    if (!user) {
      user = await User.create({ 
        walletAddress: walletAddress.toLowerCase(),
        nonce: Math.floor(Math.random() * 1000000).toString()
      });
    }
    
    res.status(200).json({ nonce: user.nonce });
  } catch (error) {
    next(error);
  }
};

// Verify signature and authenticate user
exports.verifySignature = async (req, res, next) => {
  try {
    const { walletAddress, signature } = req.body;
    
    if (!walletAddress || !signature) {
      return res.status(400).json({ error: 'Wallet address and signature are required' });
    }
    
    const user = await User.findOne({ walletAddress: walletAddress.toLowerCase() });
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Verify the signature
    const msg = `I am signing my one-time nonce: ${user.nonce}`;
    const msgBufferHex = bufferToHex(Buffer.from(msg, 'utf8'));
    const recoveredAddress = recoverPersonalSignature({
      data: msgBufferHex,
      signature: signature
    });
    
    if (recoveredAddress.toLowerCase() !== walletAddress.toLowerCase()) {
      return res.status(401).json({ error: 'Signature verification failed' });
    }
    
    // Update nonce to prevent replay attacks
    user.nonce = Math.floor(Math.random() * 1000000).toString();
    await user.save();
    
    // Create JWT token
    const token = jwt.sign(
      { walletAddress: user.walletAddress, userId: user._id },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN }
    );
    
    res.status(200).json({ 
      token,
      user: {
        walletAddress: user.walletAddress,
        displayName: user.displayName,
        bio: user.bio,
        profileLinks: user.profileLinks
      }
    });
  } catch (error) {
    next(error);
  }
};

// Get user profile
exports.getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.userId)
      .select('-nonce -__v');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// Update user profile
exports.updateProfile = async (req, res, next) => {
  try {
    const { displayName, bio, profileLinks } = req.body;
    
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { displayName, bio, profileLinks },
      { new: true, runValidators: true }
    ).select('-nonce -__v');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};