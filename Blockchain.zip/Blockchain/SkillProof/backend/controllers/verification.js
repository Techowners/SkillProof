const Credential = require('../models/Credential');
const blockchainService = require('../services/blockchain');

// Verify credential
exports.verifyCredential = async (req, res, next) => {
  try {
    const { walletAddress, tokenId } = req.body;
    
    if (!walletAddress || !tokenId) {
      return res.status(400).json({ error: 'Wallet address and token ID are required' });
    }
    
    // Check if credential exists in database
    const credential = await Credential.findOne({
      walletAddress: walletAddress.toLowerCase(),
      tokenId
    });
    
    if (!credential) {
      return res.status(404).json({ 
        verified: false,
        error: 'Credential not found in database' 
      });
    }
    
    // Verify on blockchain
    const isVerified = await blockchainService.verifyCredential(walletAddress, tokenId);
    
    res.status(200).json({
      verified: isVerified,
      credential: isVerified ? credential : null
    });
  } catch (error) {
    next(error);
  }
};

// Batch verify credentials
exports.batchVerify = async (req, res, next) => {
  try {
    const { credentials } = req.body;
    
    if (!credentials || !Array.isArray(credentials)) {
      return res.status(400).json({ error: 'Credentials array is required' });
    }
    
    const verificationResults = await Promise.all(
      credentials.map(async ({ walletAddress, tokenId }) => {
        try {
          const isVerified = await blockchainService.verifyCredential(walletAddress, tokenId);
          return { walletAddress, tokenId, verified: isVerified };
        } catch (error) {
          return { walletAddress, tokenId, verified: false, error: error.message };
        }
      })
    );
    
    res.status(200).json({ results: verificationResults });
  } catch (error) {
    next(error);
  }
};