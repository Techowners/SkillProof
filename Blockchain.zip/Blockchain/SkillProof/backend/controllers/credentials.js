const Credential = require('../models/Credential');
const User = require('../models/User');
const blockchainService = require('../services/blockchain');
const ipfsService = require('../services/ipfs');
// Get all credentials for a user
exports.getUserCredentials = async (req, res, next) => {
  try {
    const { walletAddress } = req.params;
    const credentials = await Credential.find({ 
      walletAddress: walletAddress.toLowerCase() 
    }).sort({ issuedAt: -1 });
    
    res.status(200).json(credentials);
  } catch (error) {
    next(error);
  }};
  // Mint a new credential
exports.mintCredential = async (req, res, next) => {
  try {
    const { walletAddress } = req.user;
    const { category, skill, level, proof } = req.body;
    
    // Validate input
    if (!category || !skill || !level || !proof) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    // Upload proof to IPFS
    const proofUri = await ipfsService.uploadToIPFS(proof);
    
    // Mint credential on blockchain
    const mintResult = await blockchainService.mintCredential(
      walletAddress,
      { category, skill, level, proofUri }
    );
    // Save credential to database
    const credential = await Credential.create({
      user: req.user._id,
      walletAddress: walletAddress.toLowerCase(),
      tokenId: mintResult.tokenId,
      category,
      skill,
      level,
      proofHash: mintResult.proofHash,
      proofUri,
      transactionHash: mintResult.transactionHash,
      blockchain: mintResult.blockchain
    });
    res.status(201).json(credential);
  } catch (error) {
    next(error);
  }
};
// Get credential details
exports.getCredentialDetails = async (req, res, next) => {
  try {
    const { tokenId } = req.params;
    const credential = await Credential.findOne({ tokenId })
      .populate('user', 'walletAddress displayName');
    
    if (!credential) {
      return res.status(404).json({ error: 'Credential not found' });
    }
    // Verify credential on blockchain
    const isVerified = await blockchainService.verifyCredential(
      credential.walletAddress,
      credential.tokenId
    );
    res.status(200).json({
      ...credential.toObject(),
      isVerified
    });
  } catch (error) {
    next(error);
  }
};