const { create } = require('ipfs-http-client');
const fs = require('fs');
const path = require('path');

// Initialize IPFS client
const ipfs = create({
  host: process.env.IPFS_HOST || 'ipfs.infura.io',
  port: 5001,
  protocol: 'https',
  headers: {
    authorization: `Basic ${Buffer.from(
      `${process.env.IPFS_PROJECT_ID}:${process.env.IPFS_PROJECT_SECRET}`
    ).toString('base64')}`
  }
});

// Upload file to IPFS
exports.uploadToIPFS = async (file) => {
  try {
    // In a real app, you'd handle file uploads properly
    // This is a simplified version for demo purposes
    
    // If file is a path, read the file
    let content;
    if (fs.existsSync(file)) {
      content = fs.readFileSync(file);
    } else if (typeof file === 'string') {
      content = Buffer.from(file);
    } else {
      throw new Error('Invalid file input');
    }
    
    const { cid } = await ipfs.add(content);
    
    return `ipfs://${cid.toString()}`;
  } catch (error) {
    console.error('Error uploading to IPFS:', error);
    throw error;
  }
};

// Retrieve file from IPFS
exports.getFromIPFS = async (ipfsUri) => {
  try {
    const cid = ipfsUri.replace('ipfs://', '');
    const stream = ipfs.cat(cid);
    let data = '';
    
    for await (const chunk of stream) {
      data += chunk.toString();
    }
    
    return data;
  } catch (error) {
    console.error('Error retrieving from IPFS:', error);
    throw error;
  }
};