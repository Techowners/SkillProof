const Web3 = require('web3');
const { ethers } = require('ethers');
const SkillProofContract = require('../contracts/SkillProof.json');
const config = require('../config/blockchain');

// Initialize providers for different networks
const providers = {
  ethereum: new ethers.providers.JsonRpcProvider(config.ethereum.rpcUrl),
  polygon: new ethers.providers.JsonRpcProvider(config.polygon.rpcUrl),
  optimism: new ethers.providers.JsonRpcProvider(config.optimism.rpcUrl),
  arbitrum: new ethers.providers.JsonRpcProvider(config.arbitrum.rpcUrl)
};

// Contract instances
const contracts = {};
Object.keys(providers).forEach(network => {
  contracts[network] = new ethers.Contract(
    config[network].contractAddress,
    SkillProofContract.abi,
    providers[network]
  );
});

// Mint a new credential
exports.mintCredential = async (walletAddress, { category, skill, level, proofUri }) => {
  try {
    // For demo, we'll use Polygon as default
    const network = 'polygon';
    const contract = contracts[network];
    
    // In a real app, you'd use the user's wallet to sign the transaction
    // This is a simplified version for demo purposes
    const privateKey = process.env.ADMIN_PRIVATE_KEY;
    if (!privateKey) {
      throw new Error('Admin private key not configured');
    }
    
    const wallet = new ethers.Wallet(privateKey, providers[network]);
    const contractWithSigner = contract.connect(wallet);
    
    // Generate a unique token ID
    const tokenId = ethers.BigNumber.from(
      ethers.utils.keccak256(
        ethers.utils.defaultAbiCoder.encode(
          ['address', 'string', 'string', 'string', 'string'],
          [walletAddress, category, skill, level, proofUri]
        )
      )
    ).toString();
    
    // Create proof hash
    const proofHash = ethers.utils.keccak256(
      ethers.utils.toUtf8Bytes(`${category}:${skill}:${level}:${proofUri}`)
    );
    
    // Mint the credential
    const tx = await contractWithSigner.mint(
      walletAddress,
      tokenId,
      proofHash,
      { gasLimit: 500000 }
    );
    
    await tx.wait();
    
    return {
      tokenId,
      proofHash,
      transactionHash: tx.hash,
      blockchain: network
    };
  } catch (error) {
    console.error('Error minting credential:', error);
    throw error;
  }
};

// Verify credential
exports.verifyCredential = async (walletAddress, tokenId) => {
  try {
    // Check all supported networks
    for (const network of Object.keys(contracts)) {
      const contract = contracts[network];
      
      try {
        const owner = await contract.ownerOf(tokenId);
        if (owner.toLowerCase() === walletAddress.toLowerCase()) {
          return true;
        }
      } catch (error) {
        // Token doesn't exist on this network, continue checking others
        continue;
      }
    }
    
    return false;
  } catch (error) {
    console.error('Error verifying credential:', error);
    throw error;
  }
};