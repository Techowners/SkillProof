const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const credentialSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  walletAddress: {
    type: String,
    required: true
  },
  tokenId: {
    type: String,
    required: true,
    unique: true
  },
  category: {
    type: String,
    required: true,
    enum: ['frontend', 'backend', 'blockchain', 'devops', 'data', 'cybersecurity', 'other']
  },
  skill: {
    type: String,
    required: true,
    trim: true
  },
  level: {
    type: String,
    required: true,
    enum: ['beginner', 'intermediate', 'advanced', 'expert']
  },
  proofHash: {
    type: String,
    required: true
  },
  proofUri: {
    type: String
  },
  issuer: {
    type: String,
    default: 'SkillProof'
  },
  issuedAt: {
    type: Date,
    default: Date.now
  },
  transactionHash: {
    type: String,
    required: true
  },
  blockchain: {
    type: String,
    required: true,
    enum: ['ethereum', 'polygon', 'optimism', 'arbitrum']
  }
},
{timestamps: true });

// Indexes for faster queries
credentialSchema.index({ walletAddress: 1 });
credentialSchema.index({ skill: 1 });
credentialSchema.index({ category: 1 });

module.exports = mongoose.model('Credential', credentialSchema);