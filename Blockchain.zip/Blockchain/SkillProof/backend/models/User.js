const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  walletAddress: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^0x[a-fA-F0-9]{40}$/, 'Invalid wallet address']
},
  displayName: {
    type: String,
    trim: true
  },
  bio: {
    type: String,
    trim: true
  },
  profileLinks: [{
    platform: {
        type: String,
        enum: ['github', 'twitter', 'linkedin', 'portfolio', 'other'],
        required: true
    },
    url: {
      type: String,
      required: true,
      trim: true
  }
}],
  nonce: {
    type: String,
    required: true,
    default: () => Math.floor(Math.random() * 1000000).toString()
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Index for faster wallet address lookup
userSchema.index({ walletAddress: 1 });

module.exports = mongoose.model('User', userSchema);