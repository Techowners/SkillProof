const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth');
const authMiddleware = require('../middleware/auth');

// Get nonce for wallet address
router.get('/nonce/:walletAddress', authController.getNonce);

// Verify signature and login
router.post('/verify', authController.verifySignature);

// Get user profile (authenticated)
router.get('/profile', authMiddleware.authenticate, authController.getProfile);

// Update user profile (authenticated)
router.patch('/profile', authMiddleware.authenticate, authController.updateProfile);

module.exports = router;