const express = require('express');
const router = express.Router();
const verificationController = require('../controllers/verification');

// Verify single credential
router.post('/single', verificationController.verifyCredential);

// Batch verify credentials
router.post('/batch', verificationController.batchVerify);

module.exports = router;