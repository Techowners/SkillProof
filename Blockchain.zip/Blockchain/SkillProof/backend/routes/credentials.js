const express = require('express');
const router = express.Router();
const credentialController = require('../controllers/credentials');
const authMiddleware = require('../middleware/auth');

// Get user credentials
router.get('/user/:walletAddress', credentialController.getUserCredentials);

// Mint new credential (authenticated)
router.post('/mint', authMiddleware.authenticate, credentialController.mintCredential);

// Get credential details
router.get('/:tokenId', credentialController.getCredentialDetails);

module.exports = router;